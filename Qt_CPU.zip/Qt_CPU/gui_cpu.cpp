#include "gui_cpu.h"
#include "ui_gui_cpu.h"

#include <QApplication>

GUI_CPU::GUI_CPU(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::GUI_CPU)
{
    ui->setupUi(this);

    this->simElectron.moveToThread(&this->simulationThread);

    connect(&this->simulationThread, SIGNAL(started()), &this->simElectron, SLOT(lancerSimulation()));
    connect(ui->LancerPushButton, SIGNAL(clicked()), this, SLOT(simulationSlot()));
    connect(&this->simElectron, SIGNAL(sendResultat(double)), this, SLOT(getResultat(double)));
    connect(ui->ArreterPushButton, SIGNAL(clicked()), &this->simulationThread, SLOT(quit()));
    connect(&this->simElectron, SIGNAL(sendMessage(QString)), this, SLOT(getMessage(QString)));
    connect(this, SIGNAL(sendStopThread()), &this->simulationThread, SLOT(quit()));
}

GUI_CPU::~GUI_CPU()
{
    delete ui;
}

void GUI_CPU::simulationSlot()
{
    this->simElectron.setNombreElectron(ui->nombreELectronLineEdit->text().toInt());
    this->simElectron.setEnergieInitiale(ui->energieInitialeLineEdit->text().toDouble());
    this->simElectron.setDimension(ui->dimensionsLineEdit->text().toDouble());

    double minimumCutOff = ui->energieInitialeLineEdit->text().toDouble();

    this->cutOffValues[4] = ui->cutOffAleatoireLineEdit->text().toDouble();

    if(ui->chkElastique->isChecked())
    {
        this->typeSimulation[0] = 1;
        this->cutOffValues[0] = ui->cutOffAleatoireLineEdit->text().toDouble();
    }
    else
    {
        this->typeSimulation[0] = 0;
        this->cutOffValues[0] = ui->energieInitialeLineEdit->text().toDouble() + 1;
    }


    if(ui->chkVibration->isChecked())
    {
        this->typeSimulation[1] = 1;
        this->cutOffValues[1] = ui->cutOffVibrationLineEdit->text().toDouble();

        if(cutOffValues[1] < 8.22)
        {
            cutOffValues[1] = 8.22;
            ui->cutOffVibrationLineEdit->setText("8.22");
        }

        if(cutOffValues[1] < minimumCutOff)
            minimumCutOff = cutOffValues[1];
    }
    else
    {
        this->typeSimulation[1] = 0;
        this->cutOffValues[1] = ui->energieInitialeLineEdit->text().toDouble() + 1;
    }

    if(ui->chkExcitation->isChecked())
    {
        this->typeSimulation[2] = 1;
        this->cutOffValues[2] = ui->cutOffExcitationLineEdit->text().toDouble();

        if(cutOffValues[2] < 8.22)
        {
            cutOffValues[2] = 8.22;
            ui->cutOffExcitationLineEdit->setText("8.22");
        }

        if(cutOffValues[2] < minimumCutOff)
            minimumCutOff = cutOffValues[2];
    }
    else
    {
        this->typeSimulation[2] = 0;
        this->cutOffValues[2] = ui->energieInitialeLineEdit->text().toDouble() + 1;
    }

    if(ui->chkIonisation->isChecked())
    {
        this->typeSimulation[3] = 1;
        this->cutOffValues[3] = ui->cutOffIonisationLineEdit->text().toDouble();

        if(cutOffValues[3] < 10.79)
        {
            cutOffValues[3] = 10.79;
            ui->cutOffIonisationLineEdit->setText("10.79");
        }

        if(cutOffValues[3] < minimumCutOff)
            minimumCutOff = cutOffValues[3];
    }
    else
    {
        this->typeSimulation[3] = 0;
        this->cutOffValues[3] = ui->energieInitialeLineEdit->text().toDouble() + 1;
    }

    if(minimumCutOff > this->cutOffValues[4])
    {
        this->cutOffValues[4] = minimumCutOff;
        ui->cutOffAleatoireLineEdit->setText(QString::number(minimumCutOff));
    }


    if(ui->chkEnregistrerElastique->isChecked())
       enregistrerDepotsProcessus[0] = 1;
   else
       enregistrerDepotsProcessus[0] = 0;

   if(ui->chkEnregistrerVibration->isChecked())
       enregistrerDepotsProcessus[1] = 1;
   else
       enregistrerDepotsProcessus[1] = 0;

   if(ui->chkEnregistrerExcitation->isChecked())
       enregistrerDepotsProcessus[2] = 1;
   else
       enregistrerDepotsProcessus[2] = 0;

   if(ui->chkEnregistrerIonisation->isChecked())
       enregistrerDepotsProcessus[3] = 1;
   else
       enregistrerDepotsProcessus[3] = 0;

   if(ui->chkEnregistrerSubCutOff->isChecked())
       enregistrerDepotsProcessus[4] = 1;
   else
       enregistrerDepotsProcessus[4] = 0;

   this->simElectron.setCutOffEnergie(this->cutOffValues);
   this->simElectron.setTypeSimulation(this->typeSimulation);
   this->simElectron.setEnregisterDepotsProcessus(this->enregistrerDepotsProcessus);

   int somme = 0;
   for(int i = 0; i < 4; i++)
   {
       somme += typeSimulation[i];
   }


    if(somme > 0)
        this->simulationThread.start();
    else
        ui->ResultatTextEdit->append("Impossible de lancer la simulation \n");
}

void GUI_CPU::getResultat(double val)
{
    ui->ResultatTextEdit->append(QString::number(val));
    emit sendStopThread();
}

void GUI_CPU::getMessage(QString message)
{
    ui->ResultatTextEdit->append(message);
}

void GUI_CPU::abortSimulation()
{
    emit sendStopThread();
}
