#ifndef GUI_CPU_H
#define GUI_CPU_H

#include "electron.h"

#include <QWidget>
#include <QThread>
#include <QString>

namespace Ui {
class GUI_CPU;
}

class GUI_CPU : public QWidget
{
    Q_OBJECT

public:
    explicit GUI_CPU(QWidget *parent = 0);
    ~GUI_CPU();

signals:
    void sendStopThread();

public slots:
    void simulationSlot();
    void getResultat(double);
    void getMessage(QString);
    void abortSimulation();

private:
    Ui::GUI_CPU *ui;
    Electron simElectron;
    QThread simulationThread;
    double cutOffValues[5];
    int enregistrerDepotsProcessus[5];
    int typeSimulation[4];
};

#endif // GUI_CPU_H
