#ifndef ELECTRON_H
#define ELECTRON_H

#include <QObject>
#include <QThread>
#include <QMutex>
#include <QString>

#include <time.h>
#include <iostream>
#include <cmath>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <cstring>

#include <random>

class Electron : public QObject
{
    Q_OBJECT
public:
    explicit Electron(QObject *parent = nullptr);

    struct data_res
        {
                int min;
                int max;
                int trouve;
                int niveauEnergie;
                double E;
                double sigma_sec_eff;
                double sigma_sec_eff_min;
                double sigma_sec_eff_max;
        };

        void setNombreElectron(int);
        void setEnergieInitiale(double);
        void setDimension(double);
        void setTypeSimulation(const int typeSimulation[4]);
        void setCutOffEnergie(double cutOff[5]);
        void setEnregisterDepotsProcessus(int depotsProcessus[5]);


        void simulationAleatoireCpu();

    //Fonctions communes CPU
        double Interpolation(double Xa, double Ya, double Xb, double Yb, double X);
        double frand(double min, double max);
        int inside(double Wx, double Wy, double Wz, double X, double Y, double Z);

    //Fonction simulationElastique CPU
        void getDirectionElastique(double E, double &Vx, double &Vy, double &Vz);
        double getSigmaElastique(double E);


    //Fonctions simulationVibration CPU
        double getSigmaVibration(data_res &data);
        int getIndiceEnergieVibration(data_res &data);

        void initEVibSanche(double T[38][12]);

    //Fonctions simulationExcitation CPU
        double getSigmaExcitation(data_res &data);
        int getIndiceEnergieExcitation(data_res &data);

        void initSigmaExcitation(double T[82][8]);

    //Fonctions simulationIonisation CPU
        double getSigmaIonisation(data_res &data);
        int getIndiceEnergieIonisation(data_res &data);
        double getSigmaIonisation(double E);
        double GetLambdaIonisation(double E);
        int GetIndiceEnergieIonisation(double E);
        void GetDirectionElectronSecondaire(double k, double secKinetic, double & cosTheta, double & phi);

        void getDirectionElectronPrimaireSecondaire(const double &Ti, const double &Ts, double &Vx, double &Vy, double &Vz, double &Vxs, double &Vys, double &Vzs);
        double QuadInterpolation(double e11, double e12, double e21, double e22, double xs11, double xs12, double xs21, double xs22, double t1, double t2, double t, double e);
        double GetEnergieElectronSecondaire(double k, int indice);
        double UniformRand();
        double DifferentialCrossSection(double Ti, double Tt, int Indice);
        void GetIndiceSigmaDiff(double Ti, int & min_inf, int & min_sup, int & max_inf, int & max_sup);
        void initSigmaIonisationEBorn(double T[83][8]);
        void initSigmadiffEBorn(double T[8918][7]);


    signals:
        void sendResultat(double);
        void sendMessage(QString);

    public slots:
        void lancerSimulation();

    private:
        int elecTypeSimulation[4];
        int elecEnregistrerDepotsEnergieProcessus[5];
        int elecNombreElectron;
        double elecEnergieInitiale;
        double elecDimension;
        double elecCpuTime;
        double elecCutOffEnergie[5];

        double e_Vib_Sanche[38][12];
        double sigma_excitation_e_born[82][8];
        double sigma_ionisation_e_born[83][8];
        double sigmadiff_e_born[8918][7];
        double energiesExcitation[5]; // { 8.22, 10.00, 11.24, 12.61, 13.77 };
        double energiesVibration[9];  // { 0.01, 0.024, 0.061, 0.092, 0.204, 0.417, 0.460, 0.500, 0.835 };
        double energiesIonisation[5]; // { 10.79, 13.39, 16.05, 32.30, 539.0 };

};

#endif // ELECTRON_H
