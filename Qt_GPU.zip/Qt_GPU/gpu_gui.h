#ifndef GPU_GUI_H
#define GPU_GUI_H

#include <QWidget>
#include <QThread>
#include <QString>

#include "electrongpu.h"

namespace Ui {
class GPU_GUI;
}

class GPU_GUI : public QWidget
{
    Q_OBJECT

public:
    explicit GPU_GUI(QWidget *parent = 0);
    ~GPU_GUI();

signals:
    void sendStopThread();

public slots:
    void simulationSlotGPU();
    void getResultatGPU(double);
    void getMessageGPU(QString);

private:
    Ui::GPU_GUI *ui;
    QThread simulationThreadGPU;
    ElectronGPU simElectronGPU;
    double cutOffValues[5];
    int typeSimulation[4];
    int enregistrerDepotsProcessus[5];
};

#endif // GPU_GUI_H
