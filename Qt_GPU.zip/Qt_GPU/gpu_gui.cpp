#include "gpu_gui.h"
#include "ui_gpu_gui.h"

GPU_GUI::GPU_GUI(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::GPU_GUI)
{
    ui->setupUi(this);

    this->simElectronGPU.moveToThread(&this->simulationThreadGPU);

    connect(&this->simulationThreadGPU, SIGNAL(started()), &this->simElectronGPU, SLOT(lancerSimulationGPU()));
    connect(ui->LancerPushButtonGPU, SIGNAL(clicked()), this, SLOT(simulationSlotGPU()));
    connect(&this->simElectronGPU, SIGNAL(sendResultatGPU(double)), this, SLOT(getResultatGPU(double)));
    connect(ui->ArreterPushButtonGPU, SIGNAL(clicked()), &this->simulationThreadGPU, SLOT(quit()));
    connect(&this->simElectronGPU, SIGNAL(sendMessageGPU(QString)), this, SLOT(getMessageGPU(QString)));
    connect(this, SIGNAL(sendStopThread()), &this->simulationThreadGPU, SLOT(quit()));

}

void GPU_GUI::getResultatGPU(double val)
{
    ui->ResultatTextEditGPU->append(QString::number(val));
    emit sendStopThread();
}

void GPU_GUI::getMessageGPU(QString leMessage)
{
    ui->ResultatTextEditGPU->append(leMessage);
}

void GPU_GUI::simulationSlotGPU()
{
    this->simElectronGPU.setNombreStreamsGPU(ui->nbStreamsGPU->text().toInt());
    this->simElectronGPU.setNombreElectronGPU(ui->nombreELectronLineEditGPU->text().toInt());
    this->simElectronGPU.setEnergieInitialeGPU(ui->energieInitialeLineEditGPU->text().toDouble());
    this->simElectronGPU.setDimensionGPU(ui->dimensionsLineEditGPU->text().toDouble());
    this->simElectronGPU.setNombreBlockGPU(ui->nbBlockslineEditGPU->text().toInt());
    this->simElectronGPU.setNombreThreadGPU(ui->nbThreadslineEditGPU->text().toInt());

    double minimumCutOff = ui->energieInitialeLineEditGPU->text().toDouble();

    this->cutOffValues[4] = ui->cutOffAleatoireLineEditGPU->text().toDouble();


    if(ui->chkElastique->isChecked())
    {
        this->cutOffValues[0] = ui->cutOffAleatoireLineEditGPU->text().toDouble();
        this->typeSimulation[0] = 1;
    }
    else
    {
        this->cutOffValues[0] = ui->energieInitialeLineEditGPU->text().toDouble() + 1;
        this->typeSimulation[0] = 0;
    }

    if(ui->chkVibration->isChecked())
    {
        this->cutOffValues[1] = ui->cutOffVibrationLineEditGPU->text().toDouble();
        this->typeSimulation[1] = 1;

        if(cutOffValues[1] < 8.22)
        {
            cutOffValues[1] = 8.22;
            ui->cutOffVibrationLineEditGPU->setText("8.22");
        }

        if(cutOffValues[1] < minimumCutOff)
            minimumCutOff = cutOffValues[1];
    }
    else
    {
        this->cutOffValues[1] = ui->energieInitialeLineEditGPU->text().toDouble() + 1;
        this->typeSimulation[1] = 0;
    }

    if(ui->chkExcitation->isChecked())
    {
        this->cutOffValues[2] = ui->cutOffExcitationLineEditGPU->text().toDouble();
        this->typeSimulation[2] = 1;

        if(this->cutOffValues[2] < 8.22)
        {
            this->cutOffValues[2] = 8.22;
            ui->cutOffExcitationLineEditGPU->setText("8.22");
        }

        if(cutOffValues[2] < minimumCutOff)
            minimumCutOff = cutOffValues[2];
    }
    else
    {
        this->cutOffValues[2] = ui->energieInitialeLineEditGPU->text().toDouble() + 1;
        this->typeSimulation[2] = 0;
    }

    if(ui->chkIonisation->isChecked())
    {
        this->cutOffValues[3] = ui->cutOffIonisationLineEditGPU->text().toDouble();
        this->typeSimulation[3] = 1;

        if(this->cutOffValues[3] < 10.79)
        {
            this->cutOffValues[3] = 10.79;
            ui->cutOffIonisationLineEditGPU->setText("10.79");
        }

        if(cutOffValues[3] < minimumCutOff)
            minimumCutOff = cutOffValues[3];
    }
    else
    {
        this->cutOffValues[3] = ui->energieInitialeLineEditGPU->text().toDouble() + 1;
        this->typeSimulation[3] = 0;
    }

    if(minimumCutOff > cutOffValues[4])
    {
        this->cutOffValues[4] = minimumCutOff;
        ui->cutOffAleatoireLineEditGPU->setText(QString::number(minimumCutOff));
    }


    if(ui->chk_save_elastique->isChecked())
        enregistrerDepotsProcessus[0] = 1;
    else
        enregistrerDepotsProcessus[0] = 0;

    if(ui->chk_save_vibration->isChecked())
        enregistrerDepotsProcessus[1] = 1;
    else
        enregistrerDepotsProcessus[1] = 0;

    if(ui->chk_save_excitation->isChecked())
        enregistrerDepotsProcessus[2] = 1;
    else
        enregistrerDepotsProcessus[2] = 0;

    if(ui->chk_save_ionisation->isChecked())
        enregistrerDepotsProcessus[3] = 1;
    else
        enregistrerDepotsProcessus[3] = 0;

    if(ui->chkSaveSubCutOff->isChecked())
        enregistrerDepotsProcessus[4] = 1;
    else
        enregistrerDepotsProcessus[4] = 0;

    this->simElectronGPU.setCutOffEnergieGPU(cutOffValues);
    this->simElectronGPU.setTypeSimulationGPU(typeSimulation);
    this->simElectronGPU.setEnregistrerDepotsProcessus(enregistrerDepotsProcessus);



    int somme = 0;
       for(int i = 0; i < 4; i++)
       {
           somme += typeSimulation[i];
       }


        if(somme > 0)
            this->simulationThreadGPU.start();
        else
            ui->ResultatTextEditGPU->append("Impossible de lancer la simulation \n");
}


GPU_GUI::~GPU_GUI()
{
    delete ui;
}
