#ifndef ELECTRONGPU_H
#define ELECTRONGPU_H

#include <QObject>
#include <QThread>
#include <QString>

class ElectronGPU : public QObject
{
     Q_OBJECT

public:
    explicit ElectronGPU(QObject *parent = nullptr);
    void setNombreStreamsGPU(int);
    void setNombreBlockGPU(int);
    void setNombreThreadGPU(int);
    void setNombreElectronGPU(int);
    void setEnergieInitialeGPU(double);
    void setDimensionGPU(double);
    void setTypeSimulationGPU(int typeSimulation[4]);
    void setCutOffEnergieGPU(double cutOff[5]);
    void setEnregistrerDepotsProcessus(int depotsProcessus[5]);

    void initialisationPreSimulation();

    void simulationAleatoireGPU();

signals:
    void sendResultatGPU(double);
    void sendMessageGPU(QString);

public slots:
    void lancerSimulationGPU();

private:

    int elecNombreStreamsGPU;
    int elecNombreBlockGPU;
    int elecNombreThreadGPU;
    int elecTypeSimulationGPU[4];
    int elecNombreElectronGPU;
    int elecEnregistrerDepotsProcessus[5];
    double elecEnergieInitialeGPU;
    double elecDimensionGPU;
    double elecCpuTimeGPU;
    double elecCutOffEnergieGPU[5];



};

#endif // ELECTRONGPU_H
