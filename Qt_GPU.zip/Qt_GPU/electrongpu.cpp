#include "electrongpu.h"

extern

double mainAleatoireCuda(int nombreBlock, int nombreThread, int nombreElectron, double energieInitiale, double dimensionDomaine, double cutOffEnergie[5], int enregistrerDepotsProcessus[5], int nombreStreams);
//double mainAleatoireCuda(int nombreBlock, int nombreThread, int nombreElectron, double energieInitiale, double dimensionDomaine, double cutOffEnergie[5], int typeSimulation[4]);

ElectronGPU::ElectronGPU(QObject *parent) : QObject(parent)
{

}

void ElectronGPU::setNombreStreamsGPU(int nombreStreams)
{
    this->elecNombreStreamsGPU = nombreStreams;
}

void ElectronGPU::setNombreBlockGPU(int nombreBlock)
{
    this->elecNombreBlockGPU = nombreBlock;
}

void ElectronGPU::setNombreThreadGPU(int nombreThread)
{
    this->elecNombreThreadGPU = nombreThread;
}

void ElectronGPU::setNombreElectronGPU(int nombreElectron)
{
    this->elecNombreElectronGPU = nombreElectron;
}

void ElectronGPU::setEnergieInitialeGPU(double energieInitiale)
{
    this->elecEnergieInitialeGPU = energieInitiale;
}

void ElectronGPU::setDimensionGPU(double dimensionDomaine)
{
    this->elecDimensionGPU = dimensionDomaine;
}

void ElectronGPU::setTypeSimulationGPU(int typeSimulation[4])
{
    for(int i = 0; i < 4; ++i)
        this->elecTypeSimulationGPU[i] = typeSimulation[i];
}

void ElectronGPU::setCutOffEnergieGPU(double cutOff[5])
{
    for(int i = 0; i < 5; ++i)
        this->elecCutOffEnergieGPU[i] = cutOff[i];
}

void ElectronGPU::setEnregistrerDepotsProcessus(int depotsProcessus[5])
{
    for(int i = 0; i < 5; ++i)
        this->elecEnregistrerDepotsProcessus[i] = depotsProcessus[i];
}

void ElectronGPU::simulationAleatoireGPU()
{
    QString messageSimulation;
    double cpuTime;
    int simulation = 0;

    messageSimulation = "";
    messageSimulation += "Nombre d'electron : " + QString::number(elecNombreElectronGPU) + "\n";
    messageSimulation += "Energie initiale : " + QString::number(elecEnergieInitialeGPU) + " eV\n";
    messageSimulation += "Dimension X, Y, Z : ±" + QString::number(elecDimensionGPU) + " nm\n";
    messageSimulation += "Nombre de Blocks : " + QString::number(elecNombreBlockGPU) + " \n";
    messageSimulation += "Nombre de Thread par Block : " + QString::number(elecNombreThreadGPU) + " \n";
    messageSimulation += "Type de simulation(s) selectionnee(s) :\n";

    if(this->elecTypeSimulationGPU[0] == 1)
    {
        messageSimulation += "\t - Collision Elastique\n";
        simulation += 1;
    }

    if(this->elecTypeSimulationGPU[1] == 1)
    {
        messageSimulation += "\t - Vibration\n";
        simulation += 1;
    }

    if(this->elecTypeSimulationGPU[2] == 1)
    {
        messageSimulation += "\t - Excitation\n";
        simulation += 1;
    }

    if(this->elecTypeSimulationGPU[3] == 1)
    {
        messageSimulation += "\t - Ionisation\n";
        simulation += 1;
    }

    messageSimulation += "\nLa simulation est lancee !!!\n";


    if(simulation > 0)
    {
        emit sendMessageGPU(messageSimulation);
        cpuTime = mainAleatoireCuda(elecNombreBlockGPU, elecNombreThreadGPU, elecNombreElectronGPU, elecEnergieInitialeGPU, elecDimensionGPU, elecCutOffEnergieGPU, elecEnregistrerDepotsProcessus, elecNombreStreamsGPU);
        emit sendResultatGPU(cpuTime);
    }

    else
    {
        messageSimulation = "";
        messageSimulation += "Impossible de lacer la simulation \n";
        emit sendMessageGPU(messageSimulation);
        emit sendResultatGPU(0);
    }
}

void ElectronGPU::initialisationPreSimulation()
{
    //initialisation des variables

}

void ElectronGPU::lancerSimulationGPU()
{
   ElectronGPU::simulationAleatoireGPU();
}

